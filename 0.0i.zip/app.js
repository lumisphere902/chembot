var port = process.env.PORT || 3000,
    http = require('http'),
    fs = require('fs'),
    exec = require("child_process").exec,
    html = fs.readFileSync('index.html');
var log = function(entry) {
    fs.appendFileSync('/tmp/sample-app.log', new Date().toISOString() + ' - ' + entry + '\n');
};

var server = http.createServer(function (req, res) {
    if (req.method === 'POST') {
    	log("method was post");
        var body = '';

        req.on('data', function(chunk) {
            body += chunk;
        });

        req.on('end', function() {
        	log("req.url: "+req.url);
        	log('Received message: ' + body);
            if (req.url === '/') {
                log("");
            }

            res.writeHead(200, 'OK', {'Content-Type': 'text/plain'});
            res.end();
        });
    } else if(req.method=="GET"){
    	var logi=("method was get");
    	logi+=("req.url: "+req.url);
    	logi+=("let's try running a child process!");
    	child = exec('java -jar chembot.jar "Stoichiometry" "Oxygen" "mass" "12.5" "Water" "volume" "Hydrogen + Oxygen -> Water"',
		function (error, stdout, stderr){
			logi+=('stdout: ' + stdout);
			logi+=('stderr: ' + stderr);
			if(error !== null){
  				logi+=('exec error: ' + error);
			}else{
				logi+=("no errors!");
			}
			res.writeHead(200);
        	res.write(logi);
        	res.end();
		});
        
    }
});

// Listen on port 3000, IP defaults to 127.0.0.1
server.listen(port);

// Put a friendly message on the terminal
log('Server running at http://127.0.0.1:' + port + '/');
log(exec);

// child = exec('java -jar chembot.jar "Stoichiometry" "Oxygen" "mass" "12.5" "Water" "volume" "Hydrogen + Oxygen -> Water"',
// 	function (error, stdout, stderr){
// 		log('stdout: ' + stdout);
// 		log('stderr: ' + stderr);
// 		if(error !== null){
//   			log('exec error: ' + error);
// 		}else{
// 			log("no errors!");
// 		}
// 	});

	
